import fetch from "node-fetch";
const API_BASE = process.env.API_BASE;
// Close dialog with the customer, reporting fulfillmentState of Failed or Fulfilled ("Thanks, your pizza will arrive in 20 minutes")
function close(sessionAttributes, fulfillmentState, message) {
  // return {
  //     sessionAttributes,
  //     dialogAction: {
  //         type: 'Close',
  //         fulfillmentState,
  //         message,
  //     },
  // };
  return {
    sessionState: {
      intent: {},
    },
  };
}

// --------------- Events -----------------------
const success = () => {
  return {
    state: "Fulfilled",
    dialogAction: {
      type: "Close",
    },
  };
};

const failure = () => {
  return {
    state: "Failed",
    dialogAction: {
      type: "Close",
    },
  };
};
async function dispatch(intentRequest, callback) {
  console.log(intentRequest);
  let selectedIntent = intentRequest.interpretations[0];
  const sessionAttributes = intentRequest.sessionAttributes;
  const slots = selectedIntent.slots;
  const intentName = selectedIntent.name;
  callback(
    close(intentRequest.sessionState, "Fulfilled", {
      contentType: "PlainText",
      content: `Here's your clothing`,
    })
  );
}

// doesn't need any slots, so just send to server
const handleSimpleRequest = async (intentRequest, intentName) => {
  // fetch to real backend
  let res = await fetch(`${API_BASE}/${intentName}`);
  if (res.ok) return success();
  else return failure();
};

const delegate = async (intentRequest) => {
  let currentIntent = intentRequest.interpretations[0];
  let intentName = currentIntent.name;
  console.log(intentName);

  if (intentName == "") {
    return await handleSimpleRequest(intentRequest);
  }

  // Unknown intent, should ask user to reword.
  return {};
};
// --------------- Main handler -----------------------

// Route the incoming request based on intent.
// The JSON body of the request is provided in the event slot.
exports.handler = async (event, context, callback) => {
  return await delegate(event);
  // try {
  //     dispatch(event,
  //         (response) => {
  //             callback(null, response);
  //         });
  // } catch (err) {
  //     callback(err);
  // }
};
